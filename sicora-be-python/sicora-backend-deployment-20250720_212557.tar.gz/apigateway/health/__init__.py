"""Health check del ApiGateway."""
