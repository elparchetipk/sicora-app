"""Utilidades del ApiGateway."""
