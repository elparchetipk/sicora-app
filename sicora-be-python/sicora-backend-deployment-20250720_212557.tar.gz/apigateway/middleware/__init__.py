"""Middleware del ApiGateway."""
