"""
Routers de FastAPI para la API REST.

Estos routers definen los endpoints de la API REST y conectan
las solicitudes HTTP con los casos de uso de la aplicación.
"""