"""
Schemas de Pydantic para la validación de datos.

Estos schemas definen la estructura de los datos que se reciben y envían
a través de la API REST, proporcionando validación automática.
"""