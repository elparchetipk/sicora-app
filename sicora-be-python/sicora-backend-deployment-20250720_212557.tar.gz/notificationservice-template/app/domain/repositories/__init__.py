"""
Interfaces de repositorios para la capa de dominio.

Los repositorios definen las interfaces para acceder a los datos
de las entidades del dominio, siguiendo el patrón Repository.
"""