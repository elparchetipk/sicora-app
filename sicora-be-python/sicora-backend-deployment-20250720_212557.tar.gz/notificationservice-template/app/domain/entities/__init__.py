"""
Domain Entities Package

Contiene las entidades principales del dominio de notificaciones.

Entities implementadas:
- Notification: Entidad principal de notificación

TODO: Agregar más entidades si es necesario:
- NotificationTemplate (opcional)
- NotificationChannel (opcional)
"""
