"""
Implementaciones concretas de los repositorios.

Este módulo contiene las implementaciones concretas de las interfaces
de repositorio definidas en la capa de dominio.
"""