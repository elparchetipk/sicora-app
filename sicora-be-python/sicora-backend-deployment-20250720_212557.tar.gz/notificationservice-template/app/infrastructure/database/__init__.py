"""
Configuración y modelos de la base de datos.

Este módulo contiene la configuración de la base de datos y los modelos ORM
que mapean las entidades del dominio a tablas de la base de datos.
"""