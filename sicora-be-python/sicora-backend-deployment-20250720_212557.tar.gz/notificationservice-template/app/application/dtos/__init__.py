"""
DTOs (Data Transfer Objects) para la capa de aplicación.

Los DTOs son objetos que transportan datos entre procesos, en este caso
entre la capa de presentación y la capa de aplicación.
"""