"""
Capa de Aplicación para el servicio de notificaciones.

Esta capa contiene los casos de uso que orquestan la lógica de negocio
utilizando las entidades del dominio. Actúa como intermediario entre
la capa de presentación y la capa de dominio.
"""