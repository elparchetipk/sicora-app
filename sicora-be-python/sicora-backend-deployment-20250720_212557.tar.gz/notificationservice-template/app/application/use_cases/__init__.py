"""
Casos de uso para la capa de aplicación.

Los casos de uso implementan la lógica de negocio de la aplicación,
orquestando las operaciones entre las entidades del dominio y los repositorios.
"""