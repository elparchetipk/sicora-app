# SICORA Backend Deployment Package

Este paquete contiene todos los archivos necesarios para desplegar SICORA Backend en un VPS.

## Contenido
- `deployment/` - Scripts y configuraciones de deployment
- `scripts/` - Scripts de utilidades
- `shared/` - Código compartido
- `apigateway/` - Servicio API Gateway
- `notificationservice-template/` - Servicio de notificaciones
- `pyproject.toml` - Configuración de proyecto Python
- `requirements-dev.txt` - Dependencias Python
- `.env.production` - Variables de entorno de producción

## Deployment Rápido
1. Extraer este paquete en el VPS
2. Editar `.env.production` con valores reales
3. Ejecutar: `./deployment/deploy.sh production`
4. Configurar Nginx con `deployment/nginx-sicora.conf`

## Documentación Completa
Ver el archivo `deployment/DEPLOYMENT_CHECKLIST.md` para instrucciones detalladas.
